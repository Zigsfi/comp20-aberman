Arthur Berman

Everything has been implemented correctly.
 I have discussed the assignment with Steph Cleland, Dylan Phelan, David Taus, Jason Brillon, and Tom Addison. 

I've spent roughly 8 hours on the assignment. 

