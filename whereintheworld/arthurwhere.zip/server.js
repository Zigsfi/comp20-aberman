// Express initialization
var http = require('http');
var express = require('express');
var app = express();
var bodyParse = require("body-parser");

app.use(bodyParse.urlencoded({extended: true}));

// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = 
"mongodb://admin:whereintheworld@ds053320.mongolab.com:53320/heroku_app31606450"
var mongo = require('mongodb');
var mongoclient = mongo.MongoClient;

var db = mongoUri;
var collection = null;
mongoclient.connect(mongoUri, function(err, ndb) {
    db = ndb;
    collection = db.collection('locations');
    console.log(!(collection == null));
});

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
function formatList(arr) {
    result = "<ul>"
    for (i = 0; i < arr.length; i ++) {
        result+="<li>"+arr[i].created_at+": login: " + arr[i].login + " lat: "+arr[i].lat +" lng: " + arr[i].lng+"</li>";
    }
    result += "</ul>";
    return result;

}
app.get('/', function (request, response) {
    response.set('Content-Type', 'text/html');
    collection.find({}, {limit:100, sort:[["created_at", "desc"]]}).toArray(function(err, arr){
        response.send("<html><head><title>Arthur's where</title></head><body><h1>LOCATIONS</h1>"+
            formatList(arr)+"</body></html>") ;
    });
});
app.get('/locations.json', function (request, response) {
    response.setHeader("Content-Type", "application/json");
    collection.find(
        {login:request.query.login}, 
        {sort:[["created_at", "desc"]]}).toArray(
            function (err, arr) {
                response.send(JSON.stringify(arr));
            });


});

app.get('/redline.json', function(request, response) {
    var data=''
    response.setHeader("Content-Type", "application/json");
    //The following comes from Ming's piazza post regarding http get
    var rawreq = http.get(
        {
            host:"developer.mbta.com",
            port:80,
            path:"/lib/rthr/red.json"
        }, function(res) {
        var data = '';
        console.log("Got response: " + res.statusCode);
        res.on('data', function(chunk) {
            data += chunk;
        });

        res.on('end', function() {
            response.send(data);
        });
    }).on('error', function(e) {
        console.log("Got error: " + e.message);
    });
});
app.post('/sendLocation', function(request, response) {

    response.setHeader("Content-Type", "application/json");
    if (!(request.body.login && request.body.lat && request.body.lng)) {
        response.send(JSON.stringify({}));
        return;
    }

    collection.save(
        {
            login:request.body.login, 
            lat:parseFloat(request.body.lat), 
            lng:parseFloat(request.body.lng),
            created_at:new Date()
        }, {w:1}, function (err, doc){

        });
    collection.find({}, {limit:100, sort:[["created_at", "desc"]]}).toArray(function(err, arr){

        response.send(JSON.stringify({characters:[], students:arr}))  ;
    });
});

app.listen(process.env.PORT || 3000);
